<?php
$name = $_GET['name'];
$message = $_GET['message'];

setcookie("name", $name, time()+60);
setcookie("message", $message, time()+60);

echo "Selamat Datang, $name<br>";
echo "Mesej anda: $message<br>";
?>
