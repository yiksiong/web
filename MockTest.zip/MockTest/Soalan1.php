<?php
$nama = "Zulqarnain Bin Ahmad";
$matrik = "DDT012F001";
$subjek = "DFP50193 - Web Programming";
$semester = "Empat (4)";
$institusi = "Politeknik Balik Pulau";

echo "Nama saya ialah $nama merupakan seorang pelajar $institusi. ";
echo "Nombor matrik saya bernombor $matrik. ";
echo "Saya belajar subjek $subjek pada sesi 2021/2022. ";
echo "Saya sekarang berada di semester $semester.";
?>
