<?php
$name = "";
$email = "";
$manufacturer = "";
$place = "";
$nameErr = "";
$emailErr = "";

if (isset($_POST['submit'])) {

    if (empty($_POST['name'])) {
        $nameErr = "Name is required";
    } else {
        $name = $_POST['name'];
    }

    if (empty($_POST['email'])) {
        $emailErr = "Email is required";
    } else {
        $email = $_POST['email'];
    }

    $manufacturer = $_POST['manufacturer'];
    $place = $_POST['place'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sanrizo Automotive Business Group</title>
    <style>
        .error { color: red; }
    </style>
</head>
<body>

<h2>Sanrizo Automotive Business Group</h2>
<i>Sell Your Car to Sanrizo</i><br>
<b>Get Your Car's Price Within Minutes - It's Fast And Easy!</b>
<br><br>

<form method="post" action="">
    Name: 
    <input type="text" name="name" value="<?php echo $name; ?>">
    <span class="error"> <?php echo $nameErr; ?></span>
    <br><br>

    Email: 
    <input type="text" name="email" value="<?php echo $email; ?>">
    <span class="error"> <?php echo $emailErr; ?></span>
    <br><br>

    Manufacturer: 
    <select name="manufacturer">
        <option value="Proton" <?php if ($manufacturer=="Proton") echo "selected"; ?>>Proton</option>
        <option value="Perodua" <?php if ($manufacturer=="Perodua") echo "selected"; ?>>Perodua</option>
        <option value="Toyota" <?php if ($manufacturer=="Toyota") echo "selected"; ?>>Toyota</option>
    </select>
    <br><br>

    Place of Inspection:
    <select name="place">
        <option value="Kedah" <?php if ($place=="Kedah") echo "selected"; ?>>Kedah</option>
        <option value="Penang" <?php if ($place=="Penang") echo "selected"; ?>>Penang</option>
        <option value="Selangor" <?php if ($place=="Selangor") echo "selected"; ?>>Selangor</option>
    </select>
    <br><br>

    <input type="submit" name="submit" value="Make An Appointment">
</form>

<?php
if (!empty($name) && !empty($email)) {
    echo "Hi $name, you choose $manufacturer manufacturer .Workshop is in $place.<br>";
    echo "An appointment detail has been sent to $email";

}
?>

</body>
</html>