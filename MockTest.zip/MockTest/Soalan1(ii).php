<?php
$buah = array("Manggis", "Rambutan", "Durian");
$khasiat = array("Kalsium", "Zat Besi");

echo "Negara Malaysia memang terkenal dengan buah-buahan tempatannya. ";
echo "Antaranya buah $buah[0] berupaya menurunkan berat badan, mengawal kadar gula dalam darah dan mampu meningkatkan sistem imunisasi badan.<br><br>";
echo "Manakala buah $buah[1] pula kaya dengan karbohidrat. Buah Rambutan juga mempunyai banyak mineral penting seperti $khasiat[0], $khasiat[1], Zink, Magnesium.<br><br>";
echo "Buah seterusnya ialah buah $buah[2]. Buah $buah[2] kaya dengan serat yang melambatkan peningkatan gula dalam darah, membantu penghadaman dan mengurangkan paras kolestrol.";
?>
