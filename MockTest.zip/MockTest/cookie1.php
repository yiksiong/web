<?php
if (isset($_POST['name'])) {
    $name = $_POST['name'];
    $message = $_POST['message'];
    header("Location: cookie2.php?name=$name&message=$message");
    exit();
}
?>
<form method="post" action="cookie1.php">
    Name: <input type="text" name="name"><br>
    Message: <input type="text" name="message"><br>
    <input type="submit" value="Send">
</form>
