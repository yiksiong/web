<?php
// Capture all simple variables
$name = isset($_GET['name']) ? $_GET['name'] : ""; 
$email = isset($_GET['email']) ? $_GET['email'] : ""; 
$manufacturer = isset($_GET['manufacturer']) ? $_GET['manufacturer'] : ""; 
$place = isset($_GET['place']) ? $_GET['place'] : ""; 
$fuel = isset($_GET['fuel']) ? $_GET['fuel'] : ""; 
$comments = isset($_GET['comments']) ? $_GET['comments'] : "";

// Capture the Add-ons data. It MUST be initialized as an array if not set.
// The URL structure 'addons_data[0]=X&addons_data[1]=Y' means $_GET['addons_data'] is an array.
$addons_data = isset($_GET['addons_data']) ? $_GET['addons_data'] : []; 

// --- Cookie Handling (Using string value) ---
$addons_cookie_value = is_array($addons_data) ? implode(",", $addons_data) : $addons_data;

setcookie("username", $name, time() + 60);
// ... set all other cookies ...
setcookie("addons_data", $addons_cookie_value, time() + 60);
setcookie("comments", $comments, time() + 60);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Cookies 2</title>
</head>
<body>
<?php
// --- Display Logic (Handles array conversion) ---
$addons_display_list = (empty($addons_data) || (is_array($addons_data) && count($addons_data) == 0)) 
    ? "None" 
    : (is_array($addons_data) ? implode(", ", $addons_data) : $addons_data);

// Ensure the name is uppercase for the display example
$name_display = strtoupper($name);
$comments_display = empty($comments) ? "N/A" : htmlspecialchars($comments);


echo "<div class='output'>";
echo "Hi **$name_display**, your appointment details are:<br>";
echo "You chose **$manufacturer** manufacturer. Workshop is in **$place**. ";
echo "An appointment detail has been sent to **$email**.<br>";

echo "Fuel Type: **$fuel**.<br>";
echo "Add-ons requested: **$addons_display_list**.<br>";
echo "Comments: **$comments_display**";

echo "</div>";
?>
</body>
</html>