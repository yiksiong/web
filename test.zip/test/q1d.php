<?php
// Soalan 1 (d) - File 1: cookie1.php

// 2. In cookie1.php page, check using 'if' and 'isset' code 
//    whether value for post name ($_POST['name']) is exist or not.
if (isset($_POST['name'])) {
    // i. Set variable name equals to post name.
    $name = $_POST['name']; // Example: Dyhani
    
    // ii. Set variable message equals to post message.
    $message = $_POST['message']; // Example: Adik sayang papa
    
    // iii. Set header where the location is "cookie2.php?name=$name&message=$message"[cite: 111, 113].
    // Note: header() must be called before any actual output is sent to the browser.
    header("Location: q1e.php?name=$name&message=$message");
    exit; // It's good practice to call exit after a header redirect.
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cookies 1</title>
</head>
<body>
    <form method="POST" action="q1d.php">
        Nama: <input type="text" name="name" value="Dyhani"><br>
        Mesej: <input type="text" name="message" value="Adik sayang papa"><br>
        <input type="submit" value="Send">
    </form>
</body>
</html>