<?php
// Soalan 1 (a) - Declare 5 variables and insert them into a sentence.

// 1. Variable Declaration: Declaring 5 simple variables as required.
$nama = "Zulqarnain Bin Ahmad"; // Nama: Zulqarnain Bin Ahmad [cite: 17]
$matrik = "DDT012F001"; // Matrik: DDT012F001 [cite: 18]
$subjek = "DFP50193 - Web Programming"; // Subjek: DFP50193 - Web Programming [cite: 19]
$semester = "Empat (4)"; // Semester: Empat (4) [cite: 20]
$institusi = "Politeknik Balik Pulau"; // Institusi: Politeknik Balik Pulau [cite: 21]

// 2. Output Generation: Inserting the variables into the specified sentence structure.
// The final output should match Figure 1.
echo "Nama saya ialah **$nama** merupakan seorang pelajar di **$institusi**. "; 
echo "Nombor matrik saya bernombor **$matrik**. ";
echo "Saya belajar subjek **$subjek** pada sesi 2021/2022. ";
echo "Saya sekarang berada di semester **$semester**.";

?>