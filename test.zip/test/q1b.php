<?php
// Soalan 1 (b) - Declare 2 array variables and insert them into the sentences.

// i. Declare 2 array variables
$buah = array("Manggis", "Rambutan", "Durian"); // ARRAY1: Buah [cite: 44]
$khasiat = array("Kalsium", "Zat Besi"); // ARRAY2: Khasiat [cite: 44]

// ii. Insert all array variables into the sentences
echo "Negara Malaysia memang terkenal dengan buah-buahan tempatannya.<br>";
// Buah Manggis is the first element (index 0) in the $buah array.
echo "Antaranya buah **$buah[0]** berupaya menurunkan berat badan, mengawal kadar gula dalam darah dan mampu meningkatkan sistem imunisasi badan.<br><br>";

// Buah Rambutan is the second element (index 1) in the $buah array.
// Kalsium and Zat Besi are the first and second elements (index 0 and 1) in the $khasiat array.
echo "Manakala buah **$buah[1]** pula kaya dengan karbohidrat. Buah Rambutan juga mempunyai banyak mineral penting seperti **$khasiat[0]**, **$khasiat[1]**, Zink, Magnesium.<br><br>";

// Buah Durian is the third element (index 2) in the $buah array.
echo "Buah seterusnya ialah buah **$buah[2]**. Buah **$buah[2]** kaya dengan serat yang melambatkan peningkatan gula dalam darah, membantu penghadaman dan mengurangkan paras kolestrol.";

?>