<?php
// Soalan 1 (d) - File 2: cookie2.php

// Retrieve data from URL query string (passed by header() in cookie1.php)
$name = $_GET['name']; 
$message = $_GET['message']; 

// 3.iv. Set cookie in order name, message, and time: 60 seconds.
// setcookie(name, value, expire)
// The cookie is set to expire 60 seconds from the current time.
setcookie("username", $name, time() + 60);
setcookie("usermessage", $message, time() + 60);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Cookies 2</title>
</head>
<body>
<?php
// 3. When header is successfully navigated to cookie2.php:

// 3.i. Display, "Selamat Datang, <NAME SENT>"[cite: 117].
echo "Selamat Datang. **$name**"; 

// 3.ii. Set break[cite: 119].
echo "<br>";

// 3.iii. Display, "Mesej anda: <MESSAGE SENT>"[cite: 121].
echo "Mesej anda: **$message**";

// 3.iv. Set break[cite: 124].
echo "<br>"; 
?>
</body>
</html>