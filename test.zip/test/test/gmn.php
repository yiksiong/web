<?php
// ==========================================
// VEHICLE INSPECTION ORDER FORM (Easy Version)
// ==========================================

// --- ERROR MESSAGES ---
$nameErr = $emailErr = $manufacturerErr = $placeErr = "";
$fuelErr = $addons_dataErr = "";

// --- DATA VARIABLES ---
$name = $email = $manufacturer = $place = "";
$fuel = $comments = "";
$addons_data = []; 
$display_output = false;


// ==========================================
// WHEN USER SUBMITS FORM
// ==========================================
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // --- GET BASIC INPUT ---
    $name         = trim($_POST["name"] ?? "");
    $email        = trim($_POST["email"] ?? "");
    $manufacturer = $_POST["manufacturer"] ?? "";
    $place        = $_POST["place"] ?? "";

    // --- GET NEW INPUT (Radio, Checkbox, Textarea) ---
    $fuel         = $_POST["fuel_type"] ?? "";
    $addons_data  = $_POST["addons"] ?? [];
    $comments     = trim($_POST["comments"] ?? "");

    // --- VALIDATION ---
    if ($name == "")        $nameErr = "* Name is required";
    if ($email == "")       $emailErr = "* Email is required";
    if ($manufacturer == "")$manufacturerErr = "* Manufacturer is required";
    if ($place == "")       $placeErr = "* Place is required";
    if ($fuel == "")        $fuelErr = "* Fuel type is required";
    if (empty($addons_data))$addons_dataErr = "* Select at least one add-on";

    // --- IF NO ERRORS → REDIRECT ---
    if (
        !$nameErr && !$emailErr && !$manufacturerErr &&
        !$placeErr && !$fuelErr && !$addons_dataErr
    ) {
        $addons_query = http_build_query(["addons_data" => $addons_data]);
// --------------------------------------------
// BUILD REDIRECT URL WITH ALL USER INPUT
// --------------------------------------------

    $redirect_url = "gmn2.php?"
     . "name=" . urlencode($name)
     . "&email=" . urlencode($email)
     . "&manufacturer=" . urlencode($manufacturer)
     . "&place=" . urlencode($place)
     . "&fuel=" . urlencode($fuel)
     . "&$addons_query"
     . "&comments=" . urlencode($comments);

header("Location: $redirect_url");
exit;

    }
}

// --- CONVERT NAME TO UPPERCASE FOR DISPLAY ---
$name_uppercase = $name ? strtoupper($name) : "USER";

?>
<!DOCTYPE html>
<html>
<head>
<title>SANRIZO AUTOMOTIVE BUSINESS GROUP</title>

<style>
.error {color: red;}
.output {
    border: 1px solid red;
    padding: 10px;
    margin-top: 20px;
}
</style>
</head>

<body>

<h2>SANRIZO AUTOMOTIVE BUSINESS GROUP</h2>
<h3>Sell Your Car to Sanrizo</h3>
<h4>Get Your Car's Price Within Minutes – Fast and Easy!</h4>

<!-- ======================================================
     FORM
====================================================== -->
<form method="POST">

<!-- NAME -->
Name:
<input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>">
<span class="error"><?php echo $nameErr; ?></span><br><br>

<!-- EMAIL -->
Email:
<input type="text" name="email" value="<?php echo htmlspecialchars($email); ?>">
<span class="error"><?php echo $emailErr; ?></span><br><br>

<!-- MANUFACTURER -->
Manufacturer:
<select name="manufacturer">
    <option value="" disabled <?php echo ($manufacturer == "") ? "selected" : ""; ?>>Select</option>
    <option value="Proton"   <?php echo ($manufacturer == "Proton") ? "selected" : ""; ?>>Proton</option>
    <option value="Perodua"  <?php echo ($manufacturer == "Perodua") ? "selected" : ""; ?>>Perodua</option>
    <option value="Honda"    <?php echo ($manufacturer == "Honda") ? "selected" : ""; ?>>Honda</option>
    <option value="Toyota"   <?php echo ($manufacturer == "Toyota") ? "selected" : ""; ?>>Toyota</option>
</select>
<span class="error"><?php echo $manufacturerErr; ?></span><br><br>

<!-- PLACE -->
Place of Inspection:
<select name="place">
    <option value="" disabled <?php echo ($place == "") ? "selected" : ""; ?>>Select</option>
    <option value="Penang" <?php echo ($place == "Penang") ? "selected" : ""; ?>>Penang</option>
    <option value="Kedah"  <?php echo ($place == "Kedah") ? "selected" : ""; ?>>Kedah</option>
</select>
<span class="error"><?php echo $placeErr; ?></span><br><br>

<!-- FUEL TYPE -->
<label>Fuel Type:</label>
<input type="radio" name="fuel_type" value="Petrol"   <?php echo ($fuel == "Petrol") ? "checked" : ""; ?>> Petrol
<input type="radio" name="fuel_type" value="Diesel"   <?php echo ($fuel == "Diesel") ? "checked" : ""; ?>> Diesel
<input type="radio" name="fuel_type" value="Electric" <?php echo ($fuel == "Electric") ? "checked" : ""; ?>> Electric
<span class="error"><?php echo $fuelErr; ?></span><br><br>

<!-- ADD-ONS -->
<label>Inspection Add-ons:</label><br>
<input type="checkbox" name="addons[]" value="Engine Check"
    <?php echo in_array("Engine Check", $addons_data) ? "checked" : ""; ?>>
    Engine Check<br>

<input type="checkbox" name="addons[]" value="Suspension Check"
    <?php echo in_array("Suspension Check", $addons_data) ? "checked" : ""; ?>>
    Suspension Check<br>

<input type="checkbox" name="addons[]" value="Interior Detailing"
    <?php echo in_array("Interior Detailing", $addons_data) ? "checked" : ""; ?>>
    Interior Detailing<br>

<span class="error"><?php echo $addons_dataErr; ?></span><br><br>

<!-- COMMENTS -->
<label>Extra Requirements / Comments:</label><br>
<textarea name="comments" rows="3" cols="50"><?php echo htmlspecialchars($comments); ?></textarea>
<br><br>

<input type="submit" name="submit" value="Submit Order">

</form>

<!-- ======================================================
     DISPLAY OUTPUT (FIGURE 7 STYLE + NEW DATA)
====================================================== -->
<?php
if ($display_output = true) {

    $addons_list = empty($addons_data) ? "None" : implode(", ", $addons_data);

    echo "<div class='output'>";

    echo "Hi $name_uppercase, your appointment details are:<br>";
    echo "You choose $manufacturer manufacturer. Workshop is in $place. ";
    echo "An appointment detail has been sent to $email.<br>";

    echo "Fuel Type: $fuel.<br>";
    echo "Add-ons requested: $addons_list.<br>";
    echo "Comments: " . ($comments ? htmlspecialchars($comments) : "N/A") . "";

    echo "</div>";
}
?>

</body>
</html>
