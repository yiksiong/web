<?php
// ----- CAPTURE GET DATA -----
$name         = $_GET['name'] ?? "";
$email        = $_GET['email'] ?? "";
$manufacturer = $_GET['manufacturer'] ?? "";
$place        = $_GET['place'] ?? "";
$fuel         = $_GET['fuel'] ?? "";
$comments     = $_GET['comments'] ?? "";

// Add-ons (checkbox array)
$addons_data = $_GET['addons_data'] ?? [];   // stays array

// Convert array → string (for cookie)
$addons_cookie_value = is_array($addons_data) ? implode(",", $addons_data) : $addons_data;


// ----- SET COOKIES -----
setcookie("username", $name, time() + 60);
setcookie("email", $email, time() + 60);
setcookie("manufacturer", $manufacturer, time() + 60);
setcookie("place", $place, time() + 60);
setcookie("fuel", $fuel, time() + 60);
setcookie("addons", $addons_cookie_value, time() + 60);
setcookie("comments", $comments, time() + 60);


// ----- PREPARE DATA FOR DISPLAY -----
$name_display     = strtoupper($name);
$comments_display = $comments === "" ? "N/A" : htmlspecialchars($comments);

// Add-ons list
$addons_display = empty($addons_data)
    ? "None"
    : implode(", ", $addons_data);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Appointment Summary</title>
</head>
<body>

<div style="border:1px solid red; padding:15px; width:500px;">
    <?php
        echo "Hi <b>$name_display</b>, your appointment details are:<br><br>";

        echo "Manufacturer: <b>$manufacturer</b><br>";
        echo "Inspection Place: <b>$place</b><br>";
        echo "Email: <b>$email</b><br><br>";

        echo "Fuel Type: <b>$fuel</b><br>";
        echo "Add-ons Requested: <b>$addons_display</b><br>";
        echo "Comments: <b>$comments_display</b><br>";
    ?>
</div>

</body>
</html>
