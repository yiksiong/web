<?php
// QUESTION 2: question2.php - Process the vehicle inspection order.

// Initialize variables for data and error messages
$nameErr = $emailErr = $manufacturerErr = $placeErr = ""; // Added manufacturer error variable
$name = $email = $manufacturer = $place = "";
$display_output = false; 

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Capture ALL POST data immediately, even if it's empty
    $name = isset($_POST["name"]) ? trim($_POST["name"]) : "";
    $email = isset($_POST["email"]) ? trim($_POST["email"]) : "";
    // If the "Select" option is chosen (value is empty string), $manufacturer will be ""
    $manufacturer = isset($_POST["manufacturer"]) ? $_POST["manufacturer"] : "";
    $place = isset($_POST["place"]) ? $_POST["place"] : "";

    // 2 (b) - Validation: Validate empty data for name and email (Figure 6)
    
    // Validate Name
    if (empty($name)) {
        $nameErr = "* Name is required";
    }
    
    // Validate Email
    if (empty($email)) {
        $emailErr = "* Email is required";
    }
    
    // **NEW VALIDATION: Validate Manufacturer Selection**
    if (empty($manufacturer)) {
        $manufacturerErr = "* Manufacturer is required";
    }

    if (empty($place)) {
        $placeErr = "* Place is required";
    }
    
    // Set flag to display output (Figure 7) only if NO errors exist
    if (empty($nameErr) && empty($emailErr) && empty($manufacturerErr) && empty($placeErr)) {
        $display_output = true;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>SANRIZO AUTOMOTIVE BUSINESS GROUP</title>
    <style>
        .error {color: #FF0000;}
        .output {
            border: 1px solid red; 
            padding: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <h2>SANRIZO AUTOMOTIVE BUSINESS GROUP</h2>
    <h3>Sell Your Car to Sanrizo</h3>
    <h4>Get Your Car's Price Witihin Minutes-It's Fast And Easy!</h4>

    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        
        Name: <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>">
        <span class="error"><?php echo $nameErr; ?></span><br><br>
        
        Email: <input type="text" name="email" value="<?php echo htmlspecialchars($email); ?>">
        <span class="error"><?php echo $emailErr; ?></span><br><br>

        Manufacturer: 
        <select name="manufacturer">
            <option value="" disabled <?php if (empty($manufacturer)) echo 'selected'; ?>>Select</option>
            <option value="Proton" <?php if ($manufacturer == 'Proton') echo 'selected'; ?>>Proton</option>
            <option value="Perodua" <?php if ($manufacturer == 'Perodua') echo 'selected'; ?>>Perodua</option>
            <option value="Honda" <?php if ($manufacturer == 'Honda') 
                echo 'selected'; ?>>Honda</option>
            <option value="Toyota" <?php if ($manufacturer == 'Toyota') echo 'selected'; ?>>Toyota</option>
        </select>
        <span class="error"><?php echo $manufacturerErr; ?></span><br><br>

        Place of Inspection: 
        <select name="place">
            <option value="" disabled <?php if (empty($place)) echo 'selected'; ?>>Select</option>
            <option value="Penang" <?php if ($place == 'Penang') echo 'selected'; ?>>Penang</option>
            <option value="Kedah" <?php if ($place == 'Kedah') echo 'selected'; ?>>Kedah</option>
        </select>
        <span class="error"><?php echo $placeErr; ?></span><br><br>

        <input type="submit" name="submit" value="Submit Order">

    </form>
    
    <?php
    // 2 (c) - Display the information received from the web form (Figure 7).
    if ($display_output) {
        // Output text based on Figure 7, highlighted with a div.
        echo "<div class='output'>";
        echo "Hi **$name**, you choose **$manufacturer** manufacturer. ";
        echo "Workshop is in **$place**. ";
        echo "An appointment detail has been sent to **$email**.";
        echo "</div>";
    }
    ?>

</body>
</html>