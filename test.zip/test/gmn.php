<?php
// QUESTION 2: question2.php - Process the vehicle inspection order. (Combined Exam Prep)

// Initialize variables for data and error messages
// Removed redundant $addonsErr
$nameErr = $emailErr = $manufacturerErr = $placeErr = ""; 
$fuelErr = $addons_dataErr = ""; // $addons_dataErr is the error message for the checkboxes
$fuel = $comments = ""; // Simple strings

// FIX 1: Initialize $addons_data as an array, and all error messages as empty strings
$addons_data = []; // MUST be initialized as an array

$name = $email = $manufacturer = $place = "";
$display_output = false; 

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // --- 1. CAPTURE EXISTING DATA ---
    $name = isset($_POST["name"]) ? trim($_POST["name"]) : "";
    $email = isset($_POST["email"]) ? trim($_POST["email"]) : "";
    $manufacturer = isset($_POST["manufacturer"]) ? $_POST["manufacturer"] : "";
    $place = isset($_POST["place"]) ? $_POST["place"] : "";

    // --- 2. CAPTURE NEW DATA (Radio, Checkbox, Textarea) ---
    $fuel = isset($_POST["fuel_type"]) ? $_POST["fuel_type"] : "";
    $addons_data = isset($_POST["addons"]) ? $_POST["addons"] : []; // Checkboxes return an array
    $comments = isset($_POST["comments"]) ? trim($_POST["comments"]) : ""; // Textarea

    // --- 3. VALIDATION (Required fields) ---
    
    // Validate Name
    if (empty($name)) {
        $nameErr = "* Name is required";
    }
    
    // Validate Email
    if (empty($email)) {
        $emailErr = "* Email is required";
    }
    
    // Validate Manufacturer Selection
    if (empty($manufacturer)) {
        $manufacturerErr = "* Manufacturer is required";
    }

    // Validate Place Selection
    if (empty($place)) {
        $placeErr = "* Place is required";
    }

    // **NEW VALIDATION: Radio Button (Fuel Type)**
    if (empty($fuel)) {
        $fuelErr = "* Fuel type must be selected";
    }

    // FIX 2: Checkbox Validation: Check if the ARRAY is empty, and set the ERROR variable.
    // DO NOT overwrite the $addons_data array with a string error message.
    if (empty($addons_data)) {
        $addons_dataErr = "* At least one Add-on must be selected";
    }
    
    // --- 4. CHECK FINAL STATUS ---
    // FIX 3: Removed $checkErr and added the correct checkbox error variable $addons_dataErr.
    if (empty($nameErr) && empty($emailErr) && empty($manufacturerErr) && empty($placeErr) && empty($fuelErr) && empty($addons_dataErr)) {
        $display_output = true;

    $addons_query_string = http_build_query(['addons_data' => $addons_data]);
        
        // 2. Use urlencode for other string variables for safety.
        $redirect_url = "gmn2.php?"
            . "name=" . urlencode($name)
            . "&email=" . urlencode($email)
            . "&manufacturer=" . urlencode($manufacturer)
            . "&place=" . urlencode($place)
            . "&fuel=" . urlencode($fuel)
            . "&" . $addons_query_string // Append the encoded array string
            . "&comments=" . urlencode($comments);
            
        header("Location: " . $redirect_url);
        exit;
        
        // The display logic below will now only run if the redirect fails (which it shouldn't)
        // or if you were simply displaying the output instead of redirecting.
        $display_output = true;
    }
}

// --- 5. STRING MANIPULATION EXAMPLE (FOR EXAM REVIEW) ---
// We can manipulate the Name input here before display
if (!empty($name)) {
    $name_uppercase = strtoupper($name);
} else {
    $name_uppercase = "User";
}


?>

<!DOCTYPE html>
<html>
<head>
<title>SANRIZO AUTOMOTIVE BUSINESS GROUP</title>
<style>
.error {color: #FF0000;}
.output {
border: 1px solid red; 
 padding: 10px;
margin-top: 20px;
 }
</style>
</head>
<body>

<h2>SANRIZO AUTOMOTIVE BUSINESS GROUP</h2>
<h3>Sell Your Car to Sanrizo</h3>
<h4>Get Your Car's Price Witihin Minutes-It's Fast And Easy!</h4>

<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

Name: <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>">
<span class="error"><?php echo $nameErr; ?></span><br><br>

Email: <input type="text" name="email" value="<?php echo htmlspecialchars($email); ?>">
<span class="error"><?php echo $emailErr; ?></span><br><br>

Manufacturer:
<select name="manufacturer">
<option value="" disabled <?php if (empty($manufacturer)) echo 'selected'; ?>>Select</option>
<option value="Proton" <?php if ($manufacturer == 'Proton') echo 'selected'; ?>>Proton</option>
<option value="Perodua" <?php if ($manufacturer == 'Perodua') echo 'selected'; ?>>Perodua</option>
<option value="Honda" <?php if ($manufacturer == 'Honda') echo 'selected'; ?>>Honda</option>
<option value="Toyota" <?php if ($manufacturer == 'Toyota') echo 'selected'; ?>>Toyota</option>
</select>
<span class="error"><?php echo $manufacturerErr; ?></span><br><br>

Place of Inspection:
<select name="place">
<option value="" disabled <?php if (empty($place)) echo 'selected'; ?>>Select</option>
<option value="Penang" <?php if ($place == 'Penang') echo 'selected'; ?>>Penang</option>
<option value="Kedah" <?php if ($place == 'Kedah') echo 'selected'; ?>>Kedah</option>
</select>
<span class="error"><?php echo $placeErr; ?></span><br><br>

<label>Fuel Type:</label>
<input type="radio" name="fuel_type" value="Petrol" <?php if ($fuel == 'Petrol') echo 'checked'; ?>> Petrol
<input type="radio" name="fuel_type" value="Diesel" <?php if ($fuel == 'Diesel') echo 'checked'; ?>> Diesel
<input type="radio" name="fuel_type" value="Electric" <?php if ($fuel == 'Electric') echo 'checked'; ?>> Electric
<span class="error"><?php echo $fuelErr; ?></span><br><br>

<label>Inspection Add-ons (Select All That Apply):</label><br>
<input type="checkbox" name="addons[]" value="Engine Check" <?php if (is_array($addons_data) && in_array('Engine Check', $addons_data)) echo 'checked'; ?>> Engine Check<br>
<input type="checkbox" name="addons[]" value="Suspension Check" <?php if (is_array($addons_data) && in_array('Suspension Check', $addons_data)) echo 'checked'; ?>> Suspension Check<br>
<input type="checkbox" name="addons[]" value="Interior Detailing" <?php if (is_array($addons_data) && in_array('Interior Detailing', $addons_data)) echo 'checked'; ?>> Interior Detailing
<span class="error"><?php echo $addons_dataErr; ?></span><br><br>

<label for="comments">Extra Requirements / Comments:</label><br>
<textarea id="comments" name="comments" rows="3" cols="50"><?php echo htmlspecialchars($comments); ?></textarea>
<br><br>

<input type="submit" name="submit" value="Submit Order">

</form>

<?php
// 2 (c) - Display the information received from the web form (Figure 7 + New Data).
if ($display_output) {
 $addons_list = empty($addons_data) ? "None" : implode(", ", $addons_data);

echo "<div class='output'>";
// Example of string manipulation for display (Name is Uppercase)
echo "Hi **$name_uppercase**, your appointment details are:<br>";
// Existing Data (Figure 7 structure)
echo "You chose **$manufacturer** manufacturer. Workshop is in **$place**. ";
echo "An appointment detail has been sent to **$email**.<br>";

// New Data
echo "Fuel Type: **$fuel**.<br>";
echo "Add-ons requested: **$addons_list**.<br>";
echo "Comments: **" . (empty($comments) ? "N/A" : htmlspecialchars($comments)) . "**";

echo "</div>";
}
?>

</body>
</html>